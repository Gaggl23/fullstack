const express = require('express')
const colors = require('colors')
const { MongoClient, ObjectId } = require('mongodb')

const app = express()

const uri = 'mongodb://tuga:Tuga@ac-xsorkak-shard-00-00.du4york.mongodb.net:27017,ac-xsorkak-shard-00-01.du4york.mongodb.net:27017,ac-xsorkak-shard-00-02.du4york.mongodb.net:27017/?authSource=admin&tls=true&appName=mongo1'
const client = new MongoClient(uri)

app.use(express.urlencoded({ extended: true }))
app.use(express.static('servidor/public'))
app.set('view engine', 'ejs')
app.set('views', './servidor/views')

client.connect().then(() => {
    app.listen(80, () => {
       console.log('Banco conectado!'.rainbow)
    })
})

const usuarios = () => client.db('lab10').collection('Usuarios')
const carros   = () => client.db('lab10').collection('Carros')

app.get('/', (req, res) => {
    res.redirect('/menu.html')
})

app.get('/carros', (req, res) => {
    res.render('carros')
})

app.get('/cadastro', (req, res) => {
    res.render('cadastro')
})

app.post('/CONTA', async (req, res) => {
    const { nome, login, senha } = req.body
    await usuarios().insertOne({ Nome: nome, Login: login, Senha: senha })
    res.redirect('/login')
})

app.get('/login', (req, res) => {
    res.render('login')
})

app.post('/LOGIN', async (req, res) => {
    const { login, senha } = req.body
    const usuario = await usuarios().findOne({ Login: login, Senha: senha })
    if (usuario) {
        res.redirect('/adm')
    } else {
        res.send('<script>alert("Login ou senha incorretos"); history.back()</script>')
    }
})

app.get('/listagem', async (req, res) => {
    const lista = await carros().find().toArray()
    res.render('listagem', { carros: lista })
})

app.get('/adm', async (req, res) => {
    const lista = await carros().find().toArray()
    res.render('adm', { carros: lista })
})

app.post('/carros_remover', async (req, res) => {
    const { id } = req.body
    await carros().deleteOne({_id: new ObjectId(id) })
    res.redirect('/adm')
})
    
app.post('/carros_atualizar', async (req, res) => {
    const { id, marca, modelo, ano, qtde } = req.body
    await carros().updateOne({ _id: new ObjectId(id) }, 
    { $set: { Marca: marca, Modelo: modelo, Ano: ano, Qtde: parseInt(qtde) } })
    res.redirect('/adm')
})

app.post('/carros_cadastrar', async (req, res) => {
    const { marca, modelo, ano, qtde } = req.body
    await carros().insertOne({ Marca: marca, Modelo: modelo, Ano: ano, Qtde: parseInt(qtde) })
    res.redirect('/adm')
})