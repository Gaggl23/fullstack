var express = require('express')

var colors = require('colors')

var app = express()

var { MongoClient } = require('mongodb')

var uri = 'mongodb+srv://viniciuskoga88_db_user:koga@cluster0.fyxmwed.mongodb.net/?appName=Cluster0'
const client = new MongoClient(uri);


app.use(express.urlencoded({  extended : true} ))

app.use(express.static('public'))

app.set('view engine' , 'ejs')

client.connect().then(()=>{ 
    app.listen(3000, ()=>{ 
        console.log('Banco rodando...'.green)

    })
})

app.get('/home', (req,res)=>{ 
    res.render('home')
})

app.get('/carros', (req, res)=>{ 
    res.render('carros')
})
app.get('/cadastro',(req,res)=>{ 
    res.render('cadastro')
})
app.get('/login',(req,res)=>{ 
    res.render('login')
})
app.get('/lista',(req,res)=>{ 
    res.render('lista')
})
app.get('/gerencia',(req,res)=>{ 
    res.render('gerencia')
})

app.post('/CONTA')