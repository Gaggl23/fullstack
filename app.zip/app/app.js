var express = require("express");

var app=express();

var {mongoClient}= require('mongodb');

app.set("view engine", "ejs");
app.set("views", "views")

app.use(express.static("public"));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.listen(80, ()=>{
    console.log("servidor rodando..")

})

const uri= 'mongodb+srv://tuga:tuga@mongo1.du4york.mongodb.net/?appName=mongo1';
const client = new mongoClient(uri);

var dbo = client.db('Posts');
var post =dbo.collection('Post')


//////////////////////////////////////////////



app.get("/", (req,res)=>{

    res.render("post")
})



app.get('/cadastro_post', (req,res)=>{

    res.render("cadastro_post")
    
})


app.post('/resposta', async(req,res)=>{
    const titulo = req.body.titulo;
    const resumo = req.body.resumo;
    const conteudo = req.body.conteudo;

    res.send("tudo certo");

})