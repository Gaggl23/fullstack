var express = require("express");
var app = express();

app.set("view engine", "ejs");
app.set("views", "views");

app.use(express.static("public"));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.listen(80, () => {
    console.log("servidor rodando..")
});



var { MongoClient } = require("mongodb");
const uri = 'mongodb+srv://tuga:Tuga2310@mongo1.du4york.mongodb.net/?appName=mongo1';
const client = new MongoClient(uri);

var dbo = client.db("exemplo_bd");

client.connect().then(() => {
    console.log("Banco conectado");
}).catch((err) => {
    console.log("Erro ao conectar:", err.message);
})

////////////////////////////////////////////////////




app.get("/", async (req, res) => {
    const posts = await dbo.collection('posts').find().toArray();
    res.render("post", { posts });
});

app.get('/cadastro_post', (req, res) => {
    res.render("cadastro_post");
});

app.post('/resposta', async (req, res) => {

    const newPost={

    titulo : req.body.titulo,
    resumo : req.body.resumo,
    conteudo : req.body.conteudo

    }

    console.log('post recebido');

    await dbo.collection('posts').insertOne(newPost);



    res.render("criado");

    
});